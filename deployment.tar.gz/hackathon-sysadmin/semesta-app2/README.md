# SEMESTA - System Administrator
![build](https://app.travis-ci.com/islamyakin/semesta-app2.svg?token=Atj2W1tzBfZmJuHYsvfS&branch=main)
## Details
- Repository ini berisi Web App bagian kedua, yang menampilkan detail hostname anda dengan path ```/aboutus```, app ini berjalan pada port default 3001.
- Web app ini membutuhkan koneksi internet yang akan melakukan ```GET``` ke sebuah situs web.
- Jika Laptop anda tidak terkoneksi internet Web App masih bisa berjalan dengan normal.

## Reference
[semesta-app1](https://github.com/islamyakin/semesta-app1)